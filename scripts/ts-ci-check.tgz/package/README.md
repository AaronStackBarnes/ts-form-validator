# @gbrlxvii/ts-ci-check

CI environment validation utility for TypeScript projects.

Validates build prerequisites and collects environment metrics before test runs.

## Usage

### With Jest (recommended)

```javascript
// jest.config.js
module.exports = {
  setupFiles: ['@gbrlxvii/ts-ci-check'],
  // ... other config
};
```

### Manual

```javascript
const { getCiInfo } = require('@gbrlxvii/ts-ci-check');
console.log(getCiInfo());
```
